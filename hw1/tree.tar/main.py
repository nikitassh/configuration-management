import tkinter as tk
from tkinter import scrolledtext, font
import os
import tarfile
import csv
import xml.etree.ElementTree as ET
import xml.dom.minidom
from datetime import datetime
from typing import List


def load_config(config_file: str) -> dict:
    config = {}
    with open(config_file, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            config = row
    return config


def extract_tar(tar_file: str) -> str:
    extracted_dir = "/tmp/shell_emulator"
    if not os.path.exists(extracted_dir):
        os.makedirs(extracted_dir)
    with tarfile.open(tar_file, "r") as tar:
        tar.extractall(path=extracted_dir)
    return extracted_dir


def load_log(config: dict) -> ET.Element:
    if os.path.exists(config["log_file"]):
        os.remove(config["log_file"])
    root_log = ET.Element("Logs")
    save_log(root_log, config["log_file"])
    return root_log


def save_log(root_log: ET.Element, log_file: str) -> None:
    xml_str = ET.tostring(root_log, "utf-8")
    parsed_xml = xml.dom.minidom.parseString(xml_str)
    pretty_xml_str = parsed_xml.toprettyxml(indent="  ")
    with open(log_file, "w") as log_file:
        log_file.write(pretty_xml_str)


def create_gui(root: tk.Tk, cwd: str, config: dict, root_log: ET.Element) -> None:
    text_font = font.Font(family="Courier", size=12)
    root.title("Shell Emulator")
    root.configure(bg="#2e3b4e")
    frame = tk.Frame(root, bg="#2e3b4e")
    frame.pack(padx=10, pady=10)

    output_text = scrolledtext.ScrolledText(
        frame,
        wrap=tk.WORD,
        width=80,
        height=20,
        font=text_font,
        bg="#1e1e1e",
        fg="white",
        insertbackground="white",
    )
    output_text.pack()

    input_text = tk.Entry(
        root,
        width=80,
        font=text_font,
        bg="#444444",
        fg="white",
        insertbackground="white",
    )
    input_text.pack(pady=5)
    input_text.bind(
        "<Return>",
        lambda event: process_command(
            event, input_text, cwd, config, output_text, root_log
        ),
    )
    update_prompt(output_text, cwd, config)


def update_prompt(
    output_text: scrolledtext.ScrolledText, cwd: str, config: dict
) -> None:
    prompt = f"{config['user']}@{config['hostname']}:{cwd}$ "
    output_text.insert(tk.END, prompt)
    output_text.yview(tk.END)


def process_command(
    event: tk.Event,
    input_text: tk.Entry,
    cwd: str,
    config: dict,
    output_text: scrolledtext.ScrolledText,
    root_log: ET.Element,
) -> None:
    command = input_text.get()
    input_text.delete(0, tk.END)
    execute_command(command, cwd, config, output_text, root_log)


def execute_command(
    command: str,
    cwd: str,
    config: dict,
    output_text: scrolledtext.ScrolledText,
    root_log: ET.Element,
) -> None:
    args = command.split()
    if not args:
        return
    cmd = args[0]
    if cmd == "exit":
        return
    elif cmd == "ls":
        ls_command(cwd, output_text, root_log)
    elif cmd == "cd":
        cd_command(args, cwd, output_text, root_log)
    elif cmd == "whoami":
        whoami_command(config, output_text, root_log)
    elif cmd == "tree":
        tree_command(cwd, output_text, root_log)
    elif cmd == "find":
        find_command(args, cwd, output_text, root_log)
    elif cmd == "clear":
        clear_screen(output_text, root_log)
    else:
        output_text.insert(tk.END, f"command not found: {cmd}\n")
        log_action(root_log, cmd, config["user"], is_error=True)
    update_prompt(output_text, cwd, config)


def ls_command(
    cwd: str, output_text: scrolledtext.ScrolledText, root_log: ET.Element
) -> None:
    try:
        files = os.listdir(cwd)
        for file in files:
            output_text.insert(tk.END, f"{file}\n")
        log_action(root_log, "ls", "user")
    except Exception as e:
        output_text.insert(tk.END, f"Error: {e}\n")


def cd_command(
    args: List[str],
    cwd: str,
    output_text: scrolledtext.ScrolledText,
    root_log: ET.Element,
) -> None:
    if len(args) > 1:
        new_dir = args[1]
        if new_dir == ".." or new_dir == "../":
            cwd = os.path.dirname(cwd)
        else:
            new_path = os.path.join(cwd, new_dir)
            if os.path.isdir(new_path):
                cwd = new_path
            else:
                output_text.insert(
                    tk.END, f"cd: no such file or directory: {new_dir}\n"
                )
        log_action(root_log, f"cd {new_dir}", "user")
    else:
        output_text.insert(tk.END, "cd: missing operand\n")


def whoami_command(
    config: dict, output_text: scrolledtext.ScrolledText, root_log: ET.Element
) -> None:
    output_text.insert(tk.END, f"{config['user']}\n")
    log_action(root_log, "whoami", "user")


def tree_command(
    cwd: str, output_text: scrolledtext.ScrolledText, root_log: ET.Element
) -> None:
    print_tree(cwd, output_text)
    log_action(root_log, "tree", "user")


def print_tree(
    path: str, output_text: scrolledtext.ScrolledText, level: int = 0
) -> None:
    try:
        for file in os.listdir(path):
            full_path = os.path.join(path, file)
            output_text.insert(tk.END, " " * level + f"{file}\n")
            if os.path.isdir(full_path):
                print_tree(full_path, output_text, level + 2)
    except Exception as e:
        output_text.insert(tk.END, f"Error: {e}\n")


def find_command(
    args: List[str],
    cwd: str,
    output_text: scrolledtext.ScrolledText,
    root_log: ET.Element,
) -> None:
    if len(args) < 2:
        output_text.insert(tk.END, "find: missing operand\n")
    else:
        find_files(cwd, args[1], output_text)
        log_action(root_log, f"find {args[1]}", "user")


def find_files(path: str, query: str, output_text: scrolledtext.ScrolledText) -> None:
    try:
        for file in os.listdir(path):
            if file == query:
                full_path = os.path.join(path, file)
                output_text.insert(tk.END, f"Found: {full_path}\n")
            elif os.path.isdir(os.path.join(path, file)):
                find_files(os.path.join(path, file), query, output_text)
    except Exception as e:
        output_text.insert(tk.END, f"Error: {e}\n")


def clear_screen(output_text: scrolledtext.ScrolledText, root_log: ET.Element) -> None:
    output_text.delete(1.0, tk.END)
    log_action(root_log, "clear", "user")


def log_action(
    root_log: ET.Element, command: str, user: str, is_error: bool = False
) -> None:
    action = ET.SubElement(root_log, "Action")
    if is_error:
        action.set("is_error", "true")
    action.set("user", user)
    action.set("time", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    action.set("command", command)
    save_log(root_log, "log.xml")


if __name__ == "__main__":
    config = load_config("config.csv")
    cwd = extract_tar(config["tar_file"])
    root = tk.Tk()
    root_log = load_log(config)
    create_gui(root, cwd, config, root_log)
    root.mainloop()
